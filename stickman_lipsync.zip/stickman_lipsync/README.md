# 🎵 Stickman Lip-Sync Performer

Sistema completo de animación sincronizada donde un stickman expresivo
interpreta una canción con lip-sync, emociones y movimiento corporal.

## Instalación

```bash
pip install pygame librosa numpy scipy
```

## Estructura

```
stickman_lipsync/
├── audio/
│   └── song.wav          ← Pon tu archivo WAV aquí
├── core/
│   ├── preprocessor.py   ← Fase 1: análisis de audio y letra
│   └── resolver.py       ← Fase 2: resuelve visema/emoción/letra en runtime
├── render/
│   └── character.py      ← Dibuja el stickman con pygame
├── data/                 ← Generado automáticamente
│   ├── lyrics_aligned.json
│   ├── phonemes.json
│   ├── visemes.json
│   ├── emotions.json
│   └── meta.json
├── main.py               ← Punto de entrada
└── requirements.txt
```

## Uso rápido

1. Pon tu archivo WAV en `audio/song.wav`
2. Edita `LYRICS` en `main.py` con el formato:
   ```
   0.0-3.0  | Primera línea de la canción
   3.0-6.5  | Segunda línea aquí
   ```
3. Ejecuta:
   ```bash
   python main.py
   ```

## Controles

| Tecla | Acción |
|-------|--------|
| SPACE | Play / Pausa |
| R     | Reiniciar |
| ←/→   | Saltar ±0.5s |
| ESC   | Salir |

## Modo sin audio

Si no hay archivo WAV, el sistema corre en modo silencioso con señal sintética.
La animación usa emociones y energía simuladas basadas en la letra.

## Ajuste de desfase

Si la animación no coincide con el audio, ajusta en `main.py`:
```python
ANIMATION_OFFSET = 0.0   # segundos (positivo = animación adelantada)
```

## Arquitectura

### Principio fundamental
```
❌ NO: delays, timers, sleep()
✔️ SÍ: todo en función de current_time
```

### Fase 1 — Preprocesamiento
- `Preprocessor.align_lyrics()` → `lyrics_aligned.json`
- `Preprocessor.extract_phonemes()` → `phonemes.json`  
- `Preprocessor.build_visemes()` → `visemes.json`
- `Preprocessor.analyze_emotions()` → `emotions.json`

### Fase 2 — Runtime (por frame)
```python
emotion_data = resolver.get_current_emotion(current_time, dt)
viseme_data  = resolver.get_current_viseme(current_time)
lyric_data   = resolver.get_current_lyric(current_time)
renderer.draw_frame(current_time, emotion_data, viseme_data, lyric_data, energy)
```

### Visemas soportados
| Visema  | Fonemas | Forma |
|---------|---------|-------|
| `rest`  | SIL, SP | Línea cerrada |
| `open`  | AA, AE, AH | Oval vertical grande |
| `wide`  | EH, IY  | Oval horizontal |
| `round` | OW, UW  | Oval redonda |
| `teeth` | S, Z, SH | Con dientes visibles |
| `close` | M, B, P | Oval muy cerrada |

### Emociones
| Emoción  | Bounce | Brazos | Ojos |
|----------|--------|--------|------|
| `calm`   | Lento, suave | Relajados | Normales |
| `happy`  | Fluido, alegre | Abiertos | Brillantes |
| `intense`| Rápido, fuerte | Levantados | Muy abiertos |
| `sad`    | Casi estático | Caídos | Semicerrados |

## Mejoras en producción

Para mayor precisión, instala:
- **Montreal Forced Aligner** (MFA) para alineación letra↔audio real
- **espeak-ng + phonemizer** para extracción de fonemas reales
- **pyaudio** para análisis de energía en tiempo real del stream de audio

```bash
# phonemizer para fonemas reales
pip install phonemizer

# Luego en preprocessor.py reemplaza extract_phonemes() con:
from phonemizer import phonemize
phonemes = phonemize(word, language='es', backend='espeak')
```
